<?php $__env->startSection('content'); ?>
    <div class="container mt-3">
        <?php $__currentLoopData = $students ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3">
                <div class="card-body d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0"><?php echo e($student->name); ?></h5>
                    <div>
                        <a href="<?php echo e(route('experiences.index', ['student_id' => $student->id])); ?>" class="btn btn-sm btn-primary"><?php echo e(__('trans.New Experience')); ?></a>
                        <a href="<?php echo e(route('experiences.show', [$student->id])); ?>" class="btn btn-sm btn-secondary"><?php echo e(__('trans.Reports')); ?></a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dehqanzada\Documents\GitHub\iuc-private-education\resources\views/home.blade.php ENDPATH**/ ?>