<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-sm-6 col-md-6">
                <h3>
                    <a href="<?php echo e(route('resource-groups.show', $resourceGroup->id)); ?>"><?php echo e($resourceGroup->name); ?></a>
                </h3>
            </div>
            <div class="col-sm-6 col-md-6 text-end">
                <h3>
                    <a href="<?php echo e(route('resource-groups.index')); ?>" class="btn btn-sm btn-secondary"><?php echo e(__('trans.Back')); ?></a>
                </h3>
            </div>
        </div>

        <div class="row mb-3">
            <small style="text-align: justify;"><?php echo e($resourceGroup->description); ?></small>
        </div>
        <!-- Group Items -->
        <div class="row mb-4">
            <div class="col-sm-6 col-md-6 mb-3 mb-md-0">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-primary text-white"><?php echo e(__('trans.Group Items')); ?></div>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $resourceGroup->resourceGroupItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e($item->resource->name); ?> <br>
                                <button onclick="confirmDelete(<?php echo e($item->id); ?>)" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i> <?php echo e(__('trans.Remove')); ?>

                                </button>
                                <form id="delete-form-<?php echo e($item->id); ?>"
                                      action="<?php echo e(route('resource-group-items.destroy', $item->id)); ?>" method="POST"
                                      style="display:none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>

            <!-- Resources -->
            <div class="col-sm-6 col-md-6">
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-info text-white"><?php echo e(__('trans.Resources')); ?></div>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $resources ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e($resource->name); ?>

                                <a href="<?php echo e(route('resource-group-items.edit', $resourceGroup->id)); ?>?resource_id=<?php echo e($resource->id); ?>" class="btn btn-sm btn-success">
                                    <?php echo e(__('trans.Add')); ?>

                                </a>

                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dehqanzada\Documents\GitHub\iuc-private-education\resources\views/resource-groups/show.blade.php ENDPATH**/ ?>