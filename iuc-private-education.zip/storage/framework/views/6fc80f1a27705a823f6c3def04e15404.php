<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row mb-3">
            <div class="col-md-12 d-flex justify-content-between align-items-center">
                <h2><?php echo e(__('trans.Student Lists')); ?></h2>
                <a href="<?php echo e(route('students.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('trans.Add New Student')); ?></a>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <table class="table table-hover">
                    <thead class="thead-light">
                    <tr>
                        <th class="text-start"><?php echo e(__('trans.Name')); ?></th>
                        <th class="text-end"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-start"><?php echo e($student->name); ?></td>
                            <td class="text-end">
                                <a href="<?php echo e(route('experiences.show', $student->id)); ?>" class="btn btn-sm btn-secondary">
                                    <?php echo e(__('trans.Reports')); ?>

                                </a>
                                <a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-sm btn-success">
                                    <i class="fas fa-edit"></i> <?php echo e(__('trans.Update')); ?>

                                </a>
                                <button onclick="confirmDelete(<?php echo e($student->id); ?>)" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i> <?php echo e(__('trans.Delete')); ?>

                                </button>
                                <form id="delete-form-<?php echo e($student->id); ?>"
                                      action="<?php echo e(route('students.destroy', $student->id)); ?>" method="POST"
                                      style="display:none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dehqanzada\Documents\GitHub\iuc-private-education\resources\views/students/index.blade.php ENDPATH**/ ?>