<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row justify-content-center">
            <!-- Sol Form -->
            <?php if($resource->form_type === 'left'): ?>
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-success text-white"><?php echo e(__('trans.Update')); ?> <?php echo e(__('trans.Left Form')); ?></div>
                    <img src="<?php echo e(asset('storage/images/'.$resource->image_url)); ?>" alt="">
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('resources.update', $resource->id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <input type="hidden" name="form_type" value="left">

                            <div class="form-group mb-3">
                                <label for="name" class="form-label"><?php echo e(__('trans.Name')); ?></label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($resource->name); ?>" required>
                            </div>

                            <div class="form-group mb-3">
                                <label for="auto_voiceover" class="form-label"><?php echo e(__('trans.Auto Voiceover')); ?></label>
                                <input type="checkbox" id="auto_voiceover" name="auto_voiceover" <?php echo e($resource->auto_voiceover ? 'checked' : ''); ?>>
                            </div>

                            <div class="form-group mb-3">
                                <label for="left_music" class="form-label"><?php echo e(__('trans.Music')); ?></label>
                                <input type="file" class="form-control" id="left_music" name="left_music" value="<?php echo e($resource->music_url); ?>">
                            </div>

                            <button type="submit" class="btn btn-success"><?php echo e(__('trans.Update')); ?></button>
                            <a href="<?php echo e(route('resources.index')); ?>" class="btn btn-secondary"><?php echo e(__('trans.Back')); ?></a>
                        </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Sağ Form -->
            <?php if($resource->form_type === 'right'): ?>
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-info text-white"><?php echo e(__('trans.Update')); ?> <?php echo e(__('trans.Right Form')); ?></div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('resources.update', $resource->id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <input type="hidden" name="form_type" value="right">

                            <div class="form-group mb-3">
                                <label for="image" class="form-label"><?php echo e(__('trans.Image')); ?></label>
                                <input type="file" class="form-control" id="image" name="image" value="<?php echo e($resource->image_url); ?>">
                            </div>

                            <div class="form-group mb-3">
                                <label for="right_music" class="form-label"><?php echo e(__('trans.Music')); ?></label>
                                <input type="file" class="form-control" id="right_music" name="right_music" value="<?php echo e($resource->music_url); ?>">
                            </div>

                            <button type="submit" class="btn btn-info"><?php echo e(__('trans.Update')); ?></button>
                            <a href="<?php echo e(route('resources.index')); ?>" class="btn btn-secondary"><?php echo e(__('trans.Back')); ?></a>
                        </form>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            let auto_voiceover = $('#auto_voiceover');
            let left_music = $('#left_music');
            toggleMusicField(auto_voiceover.is(':checked'));
            auto_voiceover.change(function() {
                toggleMusicField($(this).is(':checked'));
            });
            function toggleMusicField(isChecked) {
                if (isChecked) {
                    left_music.hide();
                    left_music.required = true;
                } else {
                    left_music.show();
                    left_music.required = false;
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dehqanzada\Documents\GitHub\iuc-private-education\resources\views/resources/edit.blade.php ENDPATH**/ ?>