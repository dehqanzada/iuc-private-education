<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-sm-6 col-md-6">
                <h3><?php echo e($student->name); ?></h3>
            </div>
            <div class="col-sm-6 col-md-6 text-end">
                <h3>
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-sm btn-secondary"><?php echo e(__('trans.Back')); ?></a>
                </h3>
            </div>
        </div>

        <div class="row">
            <?php $__currentLoopData = $tutorialGroups ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card border-0 shadow">
                        <div class="card-body">
                            <h5 class="card-title text-center"><?php echo e($tGroup->name); ?></h5>
                            <small style="display: block; text-align: justify;"><?php echo e($tGroup->description); ?></small>
                            <div class="text-center mt-3">
                                <?php if(!$tGroup->exams->isEmpty() && $tGroup->exams->first()->student_id == $student->id): ?>
                                    <a href="<?php echo e(route('doExperience', [$student->id, $tGroup->id])); ?>"
                                       class="btn btn-success btn-sm"><?php echo e(__('trans.Continue')); ?></a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('doExperience', [$student->id, $tGroup->id])); ?>"
                                       class="btn btn-primary btn-sm"><?php echo e(__('trans.Start')); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dehqanzada\Documents\GitHub\iuc-private-education\resources\views/experiences/index.blade.php ENDPATH**/ ?>