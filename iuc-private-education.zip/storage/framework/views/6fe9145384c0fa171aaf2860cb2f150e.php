<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-success text-white"><?php echo e(__('trans.Update Student')); ?></div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('students.update', $student->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="form-group mb-3">
                                <label for="name" class="form-label"><?php echo e(__('trans.Name')); ?></label>
                                <input type="text" class="form-control" id="name" name="name"
                                       value="<?php echo e($student->name); ?>" required>
                            </div>

                            <button type="submit" class="btn btn-success"><?php echo e(__('trans.Update')); ?></button>
                            <a href="<?php echo e(route('students.index')); ?>" class="btn btn-secondary"><?php echo e(__('trans.Back')); ?></a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dehqanzada\Documents\GitHub\iuc-private-education\resources\views/students/edit.blade.php ENDPATH**/ ?>