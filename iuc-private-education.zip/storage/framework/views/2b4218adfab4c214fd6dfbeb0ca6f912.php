<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row mb-3">
            <div class="col-md-12 d-flex justify-content-between align-items-center">
                <h2><?php echo e(__('trans.Settings')); ?></h2>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <table class="table table-hover">
                    <thead class="thead-light">
                    <tr>
                        <th class="text-start"><?php echo e(__('trans.Application')); ?></th>
                        <th class="text-end"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td class="text-start">
                            <?php echo e(__('trans.Change application Language')); ?>

                        </td>
                        <td class="text-end">
                            <?php if(app()->getLocale() === 'en'): ?>
                                <a href="<?php echo e(route('changeLanguage', 'tr')); ?>" class="btn-sm btn btn-info"><?php echo e(__('trans.Turkish')); ?></a>
                            <?php else: ?>
                                <a href="<?php echo e(route('changeLanguage', 'en')); ?>" class="btn-sm btn btn-success"><?php echo e(__('trans.English')); ?></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <br>
        <div class="card">
            <div class="card-body">
                <table class="table table-hover">
                    <thead class="thead-light">
                    <tr>
                        <th class="text-start"><?php echo e(__('trans.Text')); ?></th>
                        <th class="text-end"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!$setting->show_style): ?>
                            <tr>
                                <td class="text-start"><?php echo e(__('trans.'.$setting->name)); ?></td>
                                <td class="text-end">
                                    <?php
                                        $buttonText = $setting->status ? 'Active' : 'Passive';
                                        $buttonClass = $setting->status ? 'btn-success' : 'btn-danger';
                                        $route = $setting->status ? 'settings.edit' : 'settings.show';
                                    ?>

                                    <a href="<?php echo e(route($route, $setting->id)); ?>" class="btn btn-sm <?php echo e($buttonClass); ?>">
                                        <?php echo e(__('trans.'.$buttonText)); ?>

                                    </a>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <br>
        <div class="card">
            <div class="card-body">

                <table class="table table-hover">
                    <thead class="thead-light">
                    <tr>
                        <th class="text-start"><?php echo e(__('trans.Text style')); ?></th>
                        <th class="text-end"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <form action="<?php echo e(route('updateSettingStyle')); ?>" method="post"> <?php echo csrf_field(); ?>
                        <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($setting->show_style): ?>
                                <tr>
                                    <td class="text-start"><?php echo e(__('trans.'.$setting->name)); ?></td>
                                    <td class="text-end">
                                        <div class="col">

                                            <?php if($setting->id === 5): ?>
                                                <select name="style" id="style" class="form-select">
                                                    <?php $__currentLoopData = $styles ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $style): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option
                                                        <?php echo e(($setting->font_style == $style) ? 'selected':''); ?>

                                                        value="<?php echo e($style); ?>"><?php echo e($style); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            <?php elseif($setting->id === 6): ?>
                                                <input type="number" class="form-control" name="size"
                                                       min="10" max="150"
                                                       value="<?php echo e($setting->font_size); ?>" required>
                                            <?php elseif($setting->id === 7): ?>
                                                <select name="color" id="color" class="form-select">
                                                    <?php $__currentLoopData = $colors ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option
                                                            <?php echo e(($setting->font_color == $color) ? 'selected':''); ?>

                                                            value="<?php echo e($color); ?>"><?php echo e(__('trans.'.$color)); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td class="text-end">
                                <button class="btn btn-sm btn-outline-success" type="submit"><?php echo e(__('trans.Update')); ?></button>
                            </td>
                        </tr>
                    </form>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dehqanzada\Documents\GitHub\iuc-private-education\resources\views/settings/index.blade.php ENDPATH**/ ?>