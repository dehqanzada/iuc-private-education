<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row mb-3">
            <div class="col-md-12 d-flex justify-content-between align-items-center">
                <h2><?php echo e(__('trans.Resource List')); ?></h2>
                <a href="<?php echo e(route('resources.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('trans.Add New Resource')); ?></a>
            </div>
        </div>
        <audio id="audioPlayer" controls style="display:none;"></audio>
        <div class="card">
            <div class="card-body">
                <table class="table table-hover">
                    <thead class="thead-light">
                    <tr>
                        <th class="text-start"><?php echo e(__('trans.Name')); ?></th>
                        <th class="text-center"><?php echo e(__('trans.Image')); ?></th>
                        <th class="text-center"><?php echo e(__('trans.Music')); ?></th>
                        <th class="text-center"><?php echo e(__('trans.Auto Voiceover')); ?></th>
                        <th class="text-end"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $resources ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-start">
                                <?php if(isset($resource->name) && $resource->name !== null): ?>
                                    <?php echo e($resource->name); ?>

                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <img src="
                                <?php if(isset($resource->image_url) && $resource->image_url !== null): ?> <?php echo e(asset('storage/images/' . $resource->image_url)); ?><?php endif; ?>"
                                     class="img-fluid image-item" style="max-width: 150px; max-height: 150px;">
                            </td>
                            <td class="text-center music-item"
                                data-url="
                                <?php if(isset($resource->music_url) && $resource->music_url !== null): ?>
                                    <?php echo e(asset('storage/musics/' . $resource->music_url)); ?>

                                <?php endif; ?>
                                ">
                                <?php if(isset($resource->music_url) && $resource->music_url !== null): ?>
                                    <i class="bi bi-music-note btn btn-sm btn-info" style="font-size: 20px;"></i>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <?php if($resource->auto_voiceover): ?>
                                    <i class="bi bi-volume-up" style="font-size: 20px;"></i>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <a href="<?php echo e(route('resources.edit', $resource->id)); ?>" class="btn btn-sm btn-success">
                                    <i class="fas fa-edit"></i> <?php echo e(__('trans.Update')); ?>

                                </a>
                                <button onclick="confirmDelete(<?php echo e($resource->id); ?>)" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i> <?php echo e(__('trans.Delete')); ?>

                                </button>
                                <form id="delete-form-<?php echo e($resource->id); ?>"
                                      action="<?php echo e(route('resources.destroy', $resource->id)); ?>" method="POST"
                                      style="display:none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>


            </div>
        </div>
    </div>


    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var musicItems = document.querySelectorAll('.music-item');
            musicItems.forEach(function (musicItem) {
                musicItem.addEventListener('click', function (e) {
                    if (e.target && e.target.nodeName === "I") {
                        var musicUrl = this.getAttribute('data-url');
                        var audioPlayer = document.getElementById('audioPlayer');
                        audioPlayer.src = musicUrl;
                        audioPlayer.play();
                        // audioPlayer.style.display = 'block';
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dehqanzada\Documents\GitHub\iuc-private-education\resources\views/resources/index.blade.php ENDPATH**/ ?>