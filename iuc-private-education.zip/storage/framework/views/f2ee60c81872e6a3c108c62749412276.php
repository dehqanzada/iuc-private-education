<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row mb-3">
            <div class="col-sm-6 col-md-6">
                <h3><?php echo e($student->name); ?> -> <?php if(isset($group)): ?>
                        <?php echo e($group->name); ?>

                    <?php endif; ?></h3>
            </div>
            <div class="col-sm-6 col-md-6 text-end">
                <h3>
                    <a href="<?php echo e(route('home')); ?>" class="btn btn-sm btn-secondary"><?php echo e(__('trans.Back')); ?></a>
                </h3>
            </div>
        </div>


        <div class="container mt-4">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-body">
                            <form class="row align-items-center"
                                  action="<?php echo e(route('getReports', [$student->id, $group->id])); ?>"
                                  method="get">
                                <div class="col">
                                    <label for="studentId"
                                           class="visually-hidden"><?php echo e(__('trans.Choose Student')); ?></label>
                                    <select name="studentId" id="studentId" class="form-select">
                                        <?php $__currentLoopData = $students ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stdnt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                value="<?php echo e($stdnt->id); ?>" <?php echo e((isset($student->id) && $student->id == $stdnt->id) ? 'selected':''); ?>><?php echo e($stdnt->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col">
                                    <label for="groupId" class="visually-hidden"><?php echo e(__('trans.Choose Group')); ?></label>
                                    <select name="groupId" id="groupId" class="form-select">
                                        <?php $__currentLoopData = $groups ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option
                                                value="<?php echo e($grp->id); ?>" <?php echo e((isset($group->id) && $group->id == $grp->id) ? 'selected':''); ?>><?php echo e($grp->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-auto">
                                    <button type="submit" class="btn btn-primary"><?php echo e(__('trans.Search')); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container mt-4">
            <?php $__currentLoopData = $student->experiences ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3">
                    <img src="<?php echo e(asset('storage/experiences/' . $experience->image_url)); ?>">
                    <div class="card-body">
                        <p class="card-text text-center"><?php echo e($experience->created_at->format('d/m/Y H:i')); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dehqanzada\Documents\GitHub\iuc-private-education\resources\views/experiences/show.blade.php ENDPATH**/ ?>