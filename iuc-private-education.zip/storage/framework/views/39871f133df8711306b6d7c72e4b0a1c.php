<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row mb-3">
            <div class="col-md-12 d-flex justify-content-between align-items-center">
                <h2><?php echo e(__('trans.Resource Groups')); ?></h2>
                <a href="<?php echo e(route('resource-groups.create')); ?>" class="btn btn-sm btn-primary"><?php echo e(__('trans.Add New Resource Groups')); ?></a>
            </div>
        </div>




        <div class="row">
            <?php $__currentLoopData = $resourceGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resourceGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100 shadow">
                        <div class="card-header text-center">
                            <h5 class="card-title my-2">
                                <a href="<?php echo e(route('resource-groups.show', $resourceGroup->id)); ?>">
                                    <?php echo e($resourceGroup->name); ?> (<?php echo e($resourceGroup->resource_group_items_count); ?>)
                                </a>
                            </h5>
                        </div>
                        <div class="card-body">
                            <p class="card-text" style="text-align: justify;"><?php echo e($resourceGroup->description); ?></p>
                        </div>
                        <div class="card-footer bg-white">
                            <div class="btn-group" role="group" aria-label="Resource group actions" style="width: 100%;">
                                <a href="<?php echo e(route('resource-groups.show', $resourceGroup->id)); ?>" class="btn btn-outline-primary" style="width: 50%;">
                                    <i class="fas fa-edit"></i> <?php echo e(__('trans.Add Item')); ?>

                                </a>
                                <a href="<?php echo e(route('resource-groups.edit', $resourceGroup->id)); ?>" class="btn btn-outline-success" style="width: 50%;">
                                    <i class="fas fa-edit"></i> <?php echo e(__('trans.Update')); ?>

                                </a>
                                <button onclick="confirmDelete(<?php echo e($resourceGroup->id); ?>)" class="btn btn-outline-danger" style="width: 50%;">
                                    <i class="fas fa-trash-alt"></i> <?php echo e(__('trans.Delete')); ?>

                                </button>
                            </div>
                            <form id="delete-form-<?php echo e($resourceGroup->id); ?>"
                                  action="<?php echo e(route('resource-groups.destroy', $resourceGroup->id)); ?>" method="POST"
                                  style="display: none;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>



    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dehqanzada\Documents\GitHub\iuc-private-education\resources\views/resource-groups/index.blade.php ENDPATH**/ ?>