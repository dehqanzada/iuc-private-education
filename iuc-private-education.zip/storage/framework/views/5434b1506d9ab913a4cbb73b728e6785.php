<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <div class="row mb-3">
            <div class="col-sm-6 col-md-6">
                <h3><?php echo e(__('trans.Ongoing Examination')); ?></h3>
            </div>
            <div class="col-sm-6 col-md-6 text-end">
                <h3>
                    <?php echo e(__('trans.Number of students')); ?>: <?php echo e($totalUniqueStudents); ?>

                </h3>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <table class="table table-hover">
                    <thead class="thead-light">
                    <tr>
                        <th class="text-start"><?php echo e(__('trans.Student name')); ?></th>
                        <th class="text-start"><?php echo e(__('trans.Group name')); ?></th>
                        <th class="text-end"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-start"><?php echo e($exam->student_name); ?></td>
                                <td class="text-start"><?php echo e($exam->group_name); ?></td>
                                <td class="text-end">
                                    <a href="<?php echo e(route('doExperience', [$exam->student_id, $exam->group_id])); ?>" class="btn btn-sm btn-info">
                                        <?php echo e(__('trans.Continue with the exam')); ?>

                                    </a>
                                    <button onclick="confirmDelete(<?php echo e($exam->exam_id); ?>)" class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash-alt"></i> <?php echo e(__('trans.Delete')); ?>

                                    </button>
                                    <form id="delete-form-<?php echo e($exam->exam_id); ?>"
                                          action="<?php echo e(route('exams.destroy', $exam->exam_id)); ?>" method="POST"
                                          style="display:none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </td>
                            </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dehqanzada\Documents\GitHub\iuc-private-education\resources\views/exams/index.blade.php ENDPATH**/ ?>